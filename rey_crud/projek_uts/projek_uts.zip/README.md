# crud-generator
Full Project of Codeigniter CRUD Generater based on HarviaCode CRUD Generator

Simply access http://localhost/socianovation

Follow the guide and you will be good to start.
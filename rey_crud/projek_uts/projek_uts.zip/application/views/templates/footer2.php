<footer style="width:100%; padding:10px; background:#FFFFFF; text-align:center;">
		Copyright &copy SOCIANOVATION <?php echo date("Y"); ?> Powered By <a target="_blank" href="http://www.socianovation.com">Reyhan CRUD</a>
		 <!-- //footer -->

	
	</footer>
</div>
</div>	
       
    </body>
</html>




</br>
</br>
</br>
</br>
</br>

                <center><h1><b>Welcome</b></h1>
                	<b> Welcome To the Admin Page </b>
                	</br>
                	</br>
                	</br>
                	</br>
        <div class="row" style="margin-bottom: 20px">
            <div class="col-md-4">
               
                <a href="home">Go to The admin Page</a>
                

                
            </div>
        </div>
        </center>

<?php $this->load->view('templates/footer'); ?>	